Config = {}

Config.AllowedJobs = {"police", "ambulance", "sheriff"}  -- Kdo mu�e otevr�t MDT
Config.MaxGPSRecords = 100  -- Limit GPS z�znamu
Config.EnableANPR = true  -- Aktivovat ANPR (SPZ syst�m)
