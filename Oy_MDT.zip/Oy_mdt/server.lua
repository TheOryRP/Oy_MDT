ESX = nil
TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)

RegisterServerEvent('esx_mdt:addWarrant')
AddEventHandler('esx_mdt:addWarrant', function(citizenId, officer, reason)
    MySQL.Async.execute('INSERT INTO mdt_warrants (citizen_id, officer, reason) VALUES (@citizenId, @officer, @reason)', {
        ['@citizenId'] = citizenId,
        ['@officer'] = officer,
        ['@reason'] = reason
    })
end)

ESX.RegisterServerCallback('esx_mdt:getGPSRecords', function(source, cb, playerId)
    MySQL.Async.fetchAll('SELECT * FROM mdt_gps_logs WHERE citizen_id = @citizenId ORDER BY timestamp DESC', {
        ['@citizenId'] = playerId
    }, function(result)
        cb(result)
    end)
end)

RegisterServerEvent('esx_mdt:addGPSRecord')
AddEventHandler('esx_mdt:addGPSRecord', function(x, y, z)
    local playerId = ESX.GetPlayerData().identifier
    MySQL.Async.execute('INSERT INTO mdt_gps_logs (citizen_id, x, y, z) VALUES (@citizenId, @x, @y, @z)', {
        ['@citizenId'] = playerId,
        ['@x'] = x,
        ['@y'] = y,
        ['@z'] = z
    })
end)

RegisterServerEvent('esx_mdt:checkANPR')
AddEventHandler('esx_mdt:checkANPR', function(plate)
    MySQL.Async.fetchAll('SELECT * FROM mdt_anpr WHERE plate = @plate', {
        ['@plate'] = plate
    }, function(result)
        if result[1] then
            TriggerClientEvent('esx_mdt:showVehicleInfo', source, result[1])
        end
    end)
end)
