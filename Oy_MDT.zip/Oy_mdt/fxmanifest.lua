fx_version 'cerulean'
game 'gta5'

author 'Useful scripts'
description 'Advanced MDT system with GPS tracking, ANPR and warrants'
version '1.1.0'

client_scripts {
    'client.lua'
}

server_scripts {
    '@mysql-async/lib/MySQL.lua',
    'server.lua'
}

ui_page 'html/index.html'

files {
    'html/index.html',
    'html/script.js',
    'html/style.css'
}
