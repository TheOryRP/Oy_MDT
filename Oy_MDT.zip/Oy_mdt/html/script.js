window.addEventListener('message', function(event) {
    if (event.data.action === 'openMDT') {
        document.getElementById('mdt-container').style.display = 'block';
    } else if (event.data.action === 'closeMDT') {
        document.getElementById('mdt-container').style.display = 'none';
    }
});
