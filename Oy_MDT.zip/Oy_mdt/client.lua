local ESX = nil
Citizen.CreateThread(function()
    while ESX == nil do
        TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
        Citizen.Wait(10)
    end
end)

-- Otevren� MDT pres pr�kaz /mdt
RegisterCommand('mdt', function()
    local playerJob = ESX.GetPlayerData().job.name
    if Config.AllowedJobs[playerJob] then
        SetNuiFocus(true, true)
        SendNUIMessage({action = 'openMDT'})
    else
        ESX.ShowNotification("Nem�te opr�vnen� k otevren� MDT.")
    end
end, false)

-- Zavren� MDT pres ESC
Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        if IsControlJustPressed(0, 177) then  -- ESC
            SetNuiFocus(false, false)
            SendNUIMessage({action = 'closeMDT'})
        end
    end
end)

-- GPS tracking hr�cu
Citizen.CreateThread(function()
    while true do
        Citizen.Wait(1000)
        local playerPed = PlayerPedId()
        local pos = GetEntityCoords(playerPed)
        TriggerServerEvent('esx_mdt:addGPSRecord', pos.x, pos.y, pos.z)
    end
end)

-- ANPR (Rozpozn�v�n� SPZ)
Citizen.CreateThread(function()
    while true do
        Citizen.Wait(500)
        local vehicle = GetVehiclePedIsIn(PlayerPedId(), false)
        if vehicle ~= 0 then
            local plate = GetVehicleNumberPlateText(vehicle)
            if plate then
                TriggerServerEvent('esx_mdt:checkANPR', plate)
            end
        end
    end
end)
